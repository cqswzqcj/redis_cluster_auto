class Redis
  VERSION = "3.2.1"
end
